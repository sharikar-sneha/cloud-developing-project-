export function request(ctx) {
  return {
    operation: 'DeleteItem',
    key: {
      id: { S: ctx.args.id },
    },
  };
}

export function response(ctx) {
  return ctx.result;
}
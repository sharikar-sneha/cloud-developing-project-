export function request(ctx) {
  return {
    operation: 'PutItem',
    key: {
        id: { S: "task-13" },
    },
    attributeValues: {
      title: { S: ctx.args.title },
      dueDate: { S: ctx.args.dueDate },
      completed: { BOOL: false },
    },
  };
}

export function response(ctx) {
  return ctx.result;
}
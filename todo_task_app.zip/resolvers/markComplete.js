export function request(ctx) {
  return {
    operation: 'UpdateItem',
    key: {
      id: { S: ctx.args.id },
    },
    update: {
      expression: 'SET completed = :completed',
      expressionValues: {
        ':completed': { BOOL: true },
      },
    },
  };
}

export function response(ctx) {
  return ctx.result;
}
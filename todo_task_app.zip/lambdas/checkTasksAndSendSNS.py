import boto3
import json

dynamodb = boto3.resource('dynamodb')
cloudwatch = boto3.client('cloudwatch')
sns = boto3.client('sns')

TABLE_NAME = "Tasks"
SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:816069125906:PendingTasks_Alarm_Topic"

def lambda_handler(event, context):
    table = dynamodb.Table(TABLE_NAME)

    try:
        response = table.scan()
        items = response.get("Items", [])

        completed_count = sum(1 for item in items if item.get("completed") == True)
        pending_count = sum(1 for item in items if item.get("completed") == False)

        print(f"Completed Tasks: {completed_count}, Pending Tasks: {pending_count}")

        cloudwatch.put_metric_data(
            Namespace="TaskMetrics",
            MetricData=[
                {'MetricName': 'CompletedTasks', 'Value': completed_count, 'Unit': 'Count'},
                {'MetricName': 'PendingTasks', 'Value': pending_count, 'Unit': 'Count'}
            ]
        )

        if pending_count < 5:
            sns.publish(
                TopicArn=SNS_TOPIC_ARN,
                Message=f"Alert: Pending tasks are low ({pending_count})",
                Subject="Pending Task Alert"
            )
            print("SNS notification sent.")

        return {
            'statusCode': 200,
            'body': json.dumps({"CompletedTasks": completed_count, "PendingTasks": pending_count})
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({"error": str(e)})
        }
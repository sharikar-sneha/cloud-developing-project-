const AWS = require('aws-sdk');
const cloudwatch = new AWS.CloudWatch({ region: 'us-east-1' });

exports.handler = async (event) => {
    for (const record of event.Records) {
        if (record.eventName === 'INSERT' || record.eventName === 'MODIFY') {
            const newImage = record.dynamodb.NewImage;
            const dueDate = newImage.dueDate.S;
            const completed = newImage.completed.BOOL;

            console.log(`Task updated: dueDate=${dueDate}, completed=${completed}`);

            await cloudwatch.putMetricData({
                Namespace: 'ToDoApp',
                MetricData: [
                    {
                        MetricName: 'TasksByDueDate',
                        Dimensions: [
                            { Name: 'DueDate', Value: dueDate },
                            { Name: 'Completed', Value: completed.toString() }
                        ],
                        Value: 1,
                        Unit: 'Count',
                        Timestamp: new Date()
                    }
                ]
            }).promise();
        }
    }
    return { status: 'Success' };
};